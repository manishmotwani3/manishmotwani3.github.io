public class Harness {
    public static void main(String[] args) {
        System.out.println("main thread started");
        Harness test = new Harness();
        test.run(10,  5,  5, 50);
        System.out.println("main thread exiting");
    }

    private GenericObjectPool pool;
    private int nrIterations;

    private void run(int nrThreads, int maxActive, int maxIdle, int nrIterations) {
        try {
            this.nrIterations = nrIterations;

            System.out.println("main thread initializing pool");
            SleepingObjectFactory factory = new SleepingObjectFactory();
            pool = new GenericObjectPool(factory);
            pool.setMaxActive(maxActive);
            pool.setMaxIdle(maxIdle);

            Thread[] threads = new Thread[nrThreads];
            for (int i = 0; i < threads.length; i++) 
                threads[i] = new Thread(new MyThread(), Integer.toString(i));

            System.out.println("main thread spawning " + nrThreads + " tester threads");
            for (int i = 0; i < threads.length; i++) 
                threads[i].start();

            System.out.println("main thread waiting for tester threads to finish ...");
            for (int i = 0; i < threads.length; i++) 
                threads[i].join();

            System.out.println("main thread closing pool");
            pool.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class MyThread implements Runnable {
        public void runOnce() {
            try {
                Object o = pool.borrowObject();
                pool.returnObject(o);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void run() {
            for (int i = 0; i < nrIterations; i++) 
                runOnce();
        }
    }
}

