package triangle;

import org.junit.Test;
import static org.junit.Assert.*;

import static triangle.Triangle.Type;
import static triangle.Triangle.Type.*;

/**
 * Test class for the Triangle implementation.
 */
public class MutantAdequateTest {

    @Test
    public void killMutant1(){
        Type actual = Triangle.classify(1, 1, 1);
        Type expected = EQUILATERAL;
        assertEquals(actual, expected);
    }


    @Test
    public void killMutant4(){
        Type actual = Triangle.classify(-1, 10, 10);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void killMutant9(){
        Type actual = Triangle.classify(10, -1, 10);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void killMutant11(){
        // This one's tricky :) Involves overflows
        Type actual = Triangle.classify((1<<31) | 5, (1<<31) | 6, 10);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void killMutant18(){
        Type actual = Triangle.classify(10, 10, -1);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void killMutant20(){
        Type actual = Triangle.classify((1<<31) | 5, 10, (1<<31) | 6);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void killMutant59(){
        // EQUIVALENT
    }

    @Test
    public void killMutant63(){
        Type actual = Triangle.classify(3, 4, 7);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }


    @Test
    public void killMutant66(){
        Type actual = Triangle.classify(1, 2, 3);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }



    @Test
    public void killMutant70(){
        Type actual = Triangle.classify(4, 7, 3);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }


    @Test
    public void killMutant73(){
        Type actual = Triangle.classify(1, 3, 2);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void killMutant76(){
        Type actual = Triangle.classify((1 << 31) - 2, (1 << 30), (1 << 30) - 1);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void killMutant80(){
        Type actual = Triangle.classify(5, 7, 6);
        Type expected = SCALENE;
        assertEquals(actual, expected);
    }


    @Test
    public void killMutant81(){
        Type actual = Triangle.classify(7, 3, 4);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }


    @Test
    public void killMutant84(){
        Type actual = Triangle.classify(3, 2, 1);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }


    @Test
    public void killMutant87(){
        Type actual = Triangle.classify( (1 << 30), (1 << 30) - 1, (1 << 31) - 2);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }


    @Test
    public void killMutant101(){
        // EQUIVALENT
    }


    @Test
    public void killMutant105(){
        Type actual = Triangle.classify(10, 10, 20);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void killMutant111(){
        int a = (1 << 31) - 1;
        int b = (1 << 31) - 2;
        int c = (1 << 31) - 1;
        Type actual = Triangle.classify(a, b, c);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void killMutant122(){
        Type actual = Triangle.classify(10, 20, 10);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }


    @Test
    public void killMutant125(){
        Type actual = Triangle.classify(10, 21, 10);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void killMutant128(){
        int a = (1 << 31) - 2;
        int b = (1 << 31) - 1;
        int c = (1 << 31) - 1;
        Type actual = Triangle.classify(a, b, c);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }


    @Test
    public void killMutant136(){
        // EQUIVALENT
    }

    @Test
    public void killMutant139(){
        Type actual = Triangle.classify(20, 10, 10);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

}
