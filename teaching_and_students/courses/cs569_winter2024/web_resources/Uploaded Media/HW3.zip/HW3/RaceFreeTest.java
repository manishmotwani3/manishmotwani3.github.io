import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

class CourseRegistration implements Runnable{
    int seatsAvailable=20;
    ReadWriteLock CourseRegistrationLock = new ReentrantReadWriteLock();
    
    public void run(){
    	
    	// READ OPERATION BEGINS
    	// student (thread) tries to browse through the course and find out number of seats left
    	CourseRegistrationLock.readLock().lock();
    		try{
    	  		System.out.println(Thread.currentThread().getName() + " browses course information. ");
		        System.out.println("As per " + Thread.currentThread().getName() + ", #seats available are: " + seatsAvailable );
		        Thread.sleep(2);						// avg. time taken to find out the button to register and click
		   }catch(Exception e){}
    	CourseRegistrationLock.readLock().unlock();
      	// READ OPERATION ENDS
      	
      	
      	// WRITE OPERATION BEGINS
      	CourseRegistrationLock.writeLock().lock();
		System.out.println("\n" + Thread.currentThread().getName() + " tries to register for the course");
   	    	if(seatsAvailable>0){
   	 		try{
		              Thread.sleep(1000); 					// student gets registered on server so student has to wait
		        }catch(Exception e){}
		        	seatsAvailable--;                  			// course registered successfully by decreasing the value of "seatsAvailable"
	      
        	    System.out.println("Course REGISTERED for : "+ Thread.currentThread().getName());
        	    System.out.println("Number of seats left = " + seatsAvailable + "\n");
            
     		}else{									// no more seats left so student not registered
        	    System.out.println("course NOT REGISTERED for : "+ Thread.currentThread().getName() + "\n");
        	}
       	CourseRegistrationLock.writeLock().unlock();	            
       	// WRITE OPERATION ENDS
       	
    }
}
 
public class RaceFreeTest {
    public static void main(String args[])
    {
    	CourseRegistration obj=new CourseRegistration();          
           Thread[] students = new Thread[50];			// 50 students try to register for a course
           for (int i = 0; i < students.length; i++) {
               students[i] = new Thread(obj, Integer.toString(i));
               students[i].setName("Student"+ i);		// thread name = student<i>
           }

           for (int i = 0; i < students.length; i++) {
           	 students[i].start();
           }
           
    }
 
}
