package triangle;

import org.junit.Test;
import static org.junit.Assert.*;

import static triangle.Triangle.Type;
import static triangle.Triangle.Type.*;

/**
 * Test class for the Triangle implementation.
 */
public class ConditionCoverageTest {

    @Test
    public void coverLine20a() {
        Type actual = Triangle.classify(0, 10, 10);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine20b() {
        Type actual = Triangle.classify(10, 0, 10);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine20c() {
        Type actual = Triangle.classify(10, 10, 0);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine34a() {
        Type actual = Triangle.classify(1, 4, 2);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine34b() {
        Type actual = Triangle.classify(2, 1, 4);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine34c() {
        Type actual = Triangle.classify(4, 2, 1);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine37() {
        Type actual = Triangle.classify(2, 3, 4);
        Type expected = SCALENE;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine41() {
        // This also covers the if statements in 23-31
        Type actual = Triangle.classify(10, 10, 10);
        Type expected = EQUILATERAL;
        assertEquals(actual, expected);
    }


    @Test
    public void coverLine43a() {
        Type actual = Triangle.classify(2, 2, 3);
        Type expected = ISOSCELES;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine43b() {
        Type actual = Triangle.classify(2, 2, 5);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine45a() {
        Type actual = Triangle.classify(2, 3, 2);
        Type expected = ISOSCELES;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine45b() {
        Type actual = Triangle.classify(2, 4, 2);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine47a() {
        Type actual = Triangle.classify(3, 2, 2);
        Type expected = ISOSCELES;
        assertEquals(actual, expected);
    }

    @Test
    public void coverLine47b() {
        Type actual = Triangle.classify(2, 1, 1);
        Type expected = INVALID;
        assertEquals(actual, expected);
    }

    @Test
    public void makeTriangle() {
        // This gets rid of the last few lines that aren't covered
        Triangle trian = new Triangle();
    }
}
